*Catatan
Gunakan tools ini secara bijak

*Cara menggunakan :
ketik perintah :
-apt upgrade && apt update
-pkg install python2
-python2 gmailcrack.py

*Terimakasih telah menggunakan tools ini.

*More info cek :
-hideyorikun.blogspot.com

THANK YOU
